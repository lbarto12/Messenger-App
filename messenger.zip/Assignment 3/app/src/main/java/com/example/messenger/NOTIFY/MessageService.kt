package com.example.messenger.NOTIFY

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.example.messenger.UTIL.MessageAdapter

class MessageService : Service() {

    override fun onCreate() {
        super.onCreate()

        binder = MainBinder()
        MessageService.self = this
    }


    // BINDER
    inner class MainBinder : Binder() {
        fun getMessageService(): MessageService {
            return this@MessageService
        }
    }

    override fun onBind(p0: Intent?): IBinder? {
        return binder;
    }
    // !BINDER



    // VARS
    private lateinit var binder: MainBinder

    companion object {
        lateinit var self: MessageService
    }
    // !VARS
}