package com.example.messenger

import android.Manifest
import android.annotation.SuppressLint
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.os.Debug
import android.os.IBinder
import android.util.Log
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.messenger.NOTIFY.MessageService
import com.example.messenger.UTIL.Chat
import com.example.messenger.UTIL.Contact
import com.example.messenger.UTIL.ContactAdapter
import com.example.messenger.UTIL.MessageAdapter
import com.example.messenger.databinding.ActivityMainBinding
import com.example.messenger.ui.dashboard.ContactFragment
import com.example.messenger.ui.home.HomeFragment
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.lang.Exception
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        //setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        MainActivity.self = this
        val serviceIntent = Intent(this, MessageService::class.java)
        applicationContext.bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)

        requestForPermissions()
//        main()
    }




    private fun main(){

        Log.println(Log.DEBUG, "MAIN ACTIVITY", "main()")

        HomeFragment.self?.main()
        ContactFragment.self?.main()

        for (i in 0..30){
            messageAdapter.addChat(
                Chat(
                    Contact(
                        "Haley",
                        "657 283 2123",
                        0
                    ),
                    ArrayList()
                )
            )
        }

        for (i in retrieveContacts()){
            contactAdapter.addContact(
                i
            )
        }

    }


    // RETRIEVE CONTACTS
    @SuppressLint("Range")
    fun retrieveContacts(): ArrayList<Contact> {
        Log.println(Log.DEBUG, "CONTACT RETRIEVER", "RUNNING")
        val contacts = ArrayList<Contact>()
        var cursor: Cursor? = null

        try {
            cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, null, null, null, null
            )
        }
        catch (e: Exception){
            Log.e("ERROR ADDING CONTACT", e.message!!)
        }

        if (cursor != null && cursor.count > 0){
            while (cursor.moveToNext()){
                val contact_id = cursor.getString(
                    cursor.getColumnIndex(ContactsContract.Contacts._ID)
                )
                val contact_name = cursor.getString(
                    cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)
                )

                val temp = Array<String>(1){
                    contact_id
                }

                var phoneNumber: String? = null
                if (cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)).toInt() > 0){
                    val numCursor: Cursor? = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                        temp as Array<out String>?,
                        null
                    )

                    if (numCursor != null){
                        while (numCursor.moveToNext()){
                            phoneNumber = numCursor.getString(numCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                        }
                        numCursor.close()
                    }

                    contacts.add(
                        Contact(
                            contact_name,
                            phoneNumber?: "0",
                            contact_id.toInt()
                        )
                    )
                }
            }
        }
        Log.println(Log.DEBUG, "CONTACT RETRIEVER", "COMPLETE!")
        cursor?.close()
        return contacts
    }
    // !RETRIEVE CONTACTS


    // REQUEST PERMISSION

    private val PERMISSION_ALL  = 1

    private fun requestForPermissions(){
        Log.println(Log.DEBUG, "PERMISSION CHECK", "INIT")
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_CONTACTS)
            != PackageManager.PERMISSION_GRANTED){
            requestStorage()
        }
        else {
            Log.println(Log.DEBUG, "PERMISSION CHECK", "PERMISSIONS ALREADY ALLOWED!")
        }
    }

    private fun requestStorage(){

        Log.println(Log.DEBUG, "PERMISSION CHECK", "REQUESTING!")

        val permissions = Array<String>(3) {
            Manifest.permission.READ_EXTERNAL_STORAGE;
            Manifest.permission.READ_CONTACTS;
            Manifest.permission.WRITE_CONTACTS;
        }

        Log.println(Log.DEBUG, "PERMISSION CHECK", "FAILED - REQUESTING!")
            AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("Required to access contacts")
                .setPositiveButton("ok"){dialouge, which ->
                    ActivityCompat.requestPermissions(this,
                        permissions,
                        PERMISSION_ALL
                    )
                }
                .setNegativeButton("cancel") {dialouge, which ->
                    dialouge.dismiss()
                }
                .create()
                .show()

//        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE) ||
//            ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_CONTACTS) ||
//            ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_CONTACTS)){
//
//            Log.println(Log.DEBUG, "PERMISSION CHECK", "FAILED - REQUESTING!")
//            AlertDialog.Builder(this)
//                .setTitle("Permission Required")
//                .setMessage("Required to access contacts")
//                .setPositiveButton("ok"){dialouge, which ->
//                    ActivityCompat.requestPermissions(this,
//                        permissions,
//                        PERMISSION_ALL
//                    )
//                }
//                .setNegativeButton("cancel") {dialouge, which ->
//                    dialouge.dismiss()
//                }
//                .create()
//                .show()
//        }
//        else {
//            Log.println(Log.DEBUG, "PERMISSION CHECK", "COMPLETE!")
//            ActivityCompat.requestPermissions(this,
//                permissions as Array<out String>,
//                PERMISSION_ALL
//            )
//        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        if (requestCode == PERMISSION_ALL){
            if (grantResults.size > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                grantResults[2] == PackageManager.PERMISSION_GRANTED){
                Log.println(Log.DEBUG, "REQUEST RESULTS", "COMPLETE!")
                main()
            }
            else{
                Log.println(Log.DEBUG, "REQUEST RESULTS", "FAILED!")
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    // !REQUEST PERMISSION



    // SERVICE CONNECTION

    class SConnect : ServiceConnection {
        override fun onServiceConnected(p0: ComponentName?, p1: IBinder?) {
            Log.println(Log.DEBUG, "CONNECTION", "BOUND!!!")
            val b = p1 as MessageService.MainBinder
            messageService = b.getMessageService()
            isBound = true
            //MainActivity.self?.main()
        }

        override fun onServiceDisconnected(p0: ComponentName?) {
            isBound = false
        }

    }

    // !SERVICE CONNECTION


    // VARS
    companion object{
        public var self: MainActivity? = null
        var messageAdapter = MessageAdapter(mutableListOf())
        var contactAdapter = ContactAdapter(mutableListOf())

        lateinit var messageService: MessageService
        var isBound = false
        var serviceConnection = SConnect()
    }
    // !VARS
}