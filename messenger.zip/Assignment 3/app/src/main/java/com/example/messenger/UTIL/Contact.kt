package com.example.messenger.UTIL

import android.graphics.Bitmap

data class Contact(
    val name: String,
    val number: String,
    val id: Int,
    val email: String? = null,
    val photo: Bitmap? = null
)
